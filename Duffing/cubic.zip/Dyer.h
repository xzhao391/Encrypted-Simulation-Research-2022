#ifndef DYER
#define DYER
#include <boost/multiprecision/cpp_int.hpp>
#include <boost/multiprecision/cpp_bin_float.hpp>
#include "wide_data.h"

#include <string>
#include <iostream>
#include <fstream>

class Dyer
{
public:
	double cubic(double x,
		int bit_length, int rho, int rho_, double delta);
};
#endif