#ifndef DYER
#define DYER
#include <boost/multiprecision/cpp_int.hpp>
#include <boost/multiprecision/cpp_bin_float.hpp>
#include "wide_data.h"

#include <string>
#include <iostream>
#include <fstream>

class Dyer
{
public:
	void convert(double xdd_m1, double xd_m1, double xd_k,
        double t, double Ts, double arr[],
        int bit_length, int rho, int rho_, double delta);
};
#endif