#ifndef RTW_HEADER_encrypted_teleoperation_2021a_h_
#define RTW_HEADER_encrypted_teleoperation_2021a_h_
#ifndef encrypted_teleoperation_2021a_COMMON_INCLUDES_
#define encrypted_teleoperation_2021a_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "Linux_NoInput_cgen_wrapper.h"
#endif

#include "encrypted_teleoperation_2021a_types.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include <string.h>

#ifndef rtmGetContStateDisabled
#define rtmGetContStateDisabled(rtm)   ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
#define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
#define rtmGetContStates(rtm)          ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
#define rtmSetContStates(rtm, val)     ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
#define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
#define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetIntgData
#define rtmGetIntgData(rtm)            ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
#define rtmSetIntgData(rtm, val)       ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
#define rtmGetOdeF(rtm)                ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
#define rtmSetOdeF(rtm, val)           ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
#define rtmGetOdeY(rtm)                ((rtm)->odeY)
#endif

#ifndef rtmSetOdeY
#define rtmSetOdeY(rtm, val)           ((rtm)->odeY = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
#define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
#define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
#define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
#define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetZCCacheNeedsReset
#define rtmGetZCCacheNeedsReset(rtm)   ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
#define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
#define rtmGetdX(rtm)                  ((rtm)->derivs)
#endif

#ifndef rtmSetdX
#define rtmSetdX(rtm, val)             ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#define encrypted_teleoperation_2021a_M (encrypted_teleoperation_2021_M)

typedef struct {
  real_T xm;
  real_T xm_discrete;
  real_T xs;
  real_T xs_discrete;
  real_T Diff;
  real_T Diff_p;
  real_T Diff_e;
  real_T Diff_g;
  real_T SFunctionBuilder_o1;
  real_T SFunctionBuilder_o2;
  real_T Sum;
  real_T Sum1;
} B_encrypted_teleoperation_202_T;

typedef struct {
  real_T UD_DSTATE;
  real_T UD_DSTATE_e;
  real_T UD_DSTATE_d;
  real_T UD_DSTATE_k;
  real_T TimeStampA;
  real_T LastUAtTimeA;
  real_T TimeStampB;
  real_T LastUAtTimeB;
  real_T RateTransition_Buffer;
  real_T RateTransition1_Buffer;
  real_T TimeStampA_k;
  real_T LastUAtTimeA_p;
  real_T TimeStampB_j;
  real_T LastUAtTimeB_m;
  real_T TimeStampA_a;
  real_T LastUAtTimeA_e;
  real_T TimeStampB_f;
  real_T LastUAtTimeB_d;
  void *SFunctionBuilder_PWORK;
} DW_encrypted_teleoperation_20_T;

typedef struct {
  real_T masterdynamics_CSTATE[2];
  real_T slavedynamics_CSTATE[2];
} X_encrypted_teleoperation_202_T;

typedef struct {
  real_T masterdynamics_CSTATE[2];
  real_T slavedynamics_CSTATE[2];
} XDot_encrypted_teleoperation__T;

typedef struct {
  boolean_T masterdynamics_CSTATE[2];
  boolean_T slavedynamics_CSTATE[2];
} XDis_encrypted_teleoperation__T;

#ifndef ODE5_INTG
#define ODE5_INTG

typedef struct {
  real_T *y;
  real_T *f[6];
} ODE5_IntgData;

#endif

typedef struct {
  real_T masterdisp;
  real_T slavedisp;
} ExtY_encrypted_teleoperation__T;

struct P_encrypted_teleoperation_202_T_ {
  real_T benv;
  real_T bms;
  real_T fm;
  real_T kenv;
  real_T kms;
  real_T mm;
  real_T mms;
  real_T ms;
  real_T um;
  real_T us;
  real_T xbar;
  real_T DiscreteDerivative2_ICPrevScale;
  real_T DiscreteDerivative3_ICPrevScale;
  real_T DiscreteDerivative4_ICPrevScale;
  real_T DiscreteDerivative5_ICPrevScale;
  real_T CompareToConstant1_const;
  real_T masterdynamics_A[2];
  real_T masterdynamics_C[2];
  real_T Step_Time;
  real_T Step_Y0;
  real_T slavedynamics_A[2];
  real_T slavedynamics_C[2];
  real_T TSamp_WtEt;
  real_T TSamp_WtEt_n;
  real_T TSamp_WtEt_i;
  real_T TSamp_WtEt_i4;
  real_T bit_length_Value;
  real_T rho_Value;
  real_T rho_Value_o;
  real_T delta_Value;
  real_T SFunctionBuilder_P1;
};

struct tag_RTM_encrypted_teleoperati_T {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;
  X_encrypted_teleoperation_202_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[4];
  real_T odeF[6][4];
  ODE5_IntgData intgData;
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    struct {
      uint8_T TID[3];
    } TaskCounters;

    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[3];
  } Timing;
};

extern P_encrypted_teleoperation_202_T encrypted_teleoperation_2021a_P;
extern B_encrypted_teleoperation_202_T encrypted_teleoperation_2021a_B;
extern X_encrypted_teleoperation_202_T encrypted_teleoperation_2021a_X;
extern DW_encrypted_teleoperation_20_T encrypted_teleoperation_2021_DW;
extern ExtY_encrypted_teleoperation__T encrypted_teleoperation_2021a_Y;
extern void encrypted_teleoperation_2021a_initialize(void);
extern void encrypted_teleoperation_2021a_step(void);
extern void encrypted_teleoperation_2021a_terminate(void);
extern RT_MODEL_encrypted_teleoperat_T *const encrypted_teleoperation_2021_M;
extern void fmu_LogOutput();

#endif
