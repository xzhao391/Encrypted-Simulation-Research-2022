#include "encrypted_teleoperation_2021a_macros.h"
#include "encrypted_teleoperation_2021a.h"
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "encrypted_teleoperation_2021a_private.h"
#include <string.h>

B_encrypted_teleoperation_202_T encrypted_teleoperation_2021a_B;
X_encrypted_teleoperation_202_T encrypted_teleoperation_2021a_X;
DW_encrypted_teleoperation_20_T encrypted_teleoperation_2021_DW;
ExtY_encrypted_teleoperation__T encrypted_teleoperation_2021a_Y;
static RT_MODEL_encrypted_teleoperat_T encrypted_teleoperation_2021_M_;
RT_MODEL_encrypted_teleoperat_T *const encrypted_teleoperation_2021_M =
  &encrypted_teleoperation_2021_M_;
static void rate_scheduler(void);
static void rate_scheduler(void)
{
  (encrypted_teleoperation_2021_M->Timing.TaskCounters.TID[2])++;
  if ((encrypted_teleoperation_2021_M->Timing.TaskCounters.TID[2]) > 19) {
    encrypted_teleoperation_2021_M->Timing.TaskCounters.TID[2] = 0;
  }
}

static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  static const real_T rt_ODE5_A[6] = {
    1.0/5.0, 3.0/10.0, 4.0/5.0, 8.0/9.0, 1.0, 1.0
  };

  static const real_T rt_ODE5_B[6][6] = {
    { 1.0/5.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

    { 3.0/40.0, 9.0/40.0, 0.0, 0.0, 0.0, 0.0 },

    { 44.0/45.0, -56.0/15.0, 32.0/9.0, 0.0, 0.0, 0.0 },

    { 19372.0/6561.0, -25360.0/2187.0, 64448.0/6561.0, -212.0/729.0, 0.0, 0.0 },

    { 9017.0/3168.0, -355.0/33.0, 46732.0/5247.0, 49.0/176.0, -5103.0/18656.0,
      0.0 },

    { 35.0/384.0, 0.0, 500.0/1113.0, 125.0/192.0, -2187.0/6784.0, 11.0/84.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE5_IntgData *id = (ODE5_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T *f3 = id->f[3];
  real_T *f4 = id->f[4];
  real_T *f5 = id->f[5];
  real_T hB[6];
  int_T i;
  int_T nXc = 4;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));
  rtsiSetdX(si, f0);
  encrypted_teleoperation_2021a_derivatives();
  hB[0] = h * rt_ODE5_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[0]);
  rtsiSetdX(si, f1);
  encrypted_teleoperation_2021a_step();
  encrypted_teleoperation_2021a_derivatives();
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE5_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[1]);
  rtsiSetdX(si, f2);
  encrypted_teleoperation_2021a_step();
  encrypted_teleoperation_2021a_derivatives();
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE5_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[2]);
  rtsiSetdX(si, f3);
  encrypted_teleoperation_2021a_step();
  encrypted_teleoperation_2021a_derivatives();
  for (i = 0; i <= 3; i++) {
    hB[i] = h * rt_ODE5_B[3][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3]);
  }

  rtsiSetT(si, t + h*rt_ODE5_A[3]);
  rtsiSetdX(si, f4);
  encrypted_teleoperation_2021a_step();
  encrypted_teleoperation_2021a_derivatives();
  for (i = 0; i <= 4; i++) {
    hB[i] = h * rt_ODE5_B[4][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3] + f4[i]*hB[4]);
  }

  rtsiSetT(si, tnew);
  rtsiSetdX(si, f5);
  encrypted_teleoperation_2021a_step();
  encrypted_teleoperation_2021a_derivatives();
  for (i = 0; i <= 5; i++) {
    hB[i] = h * rt_ODE5_B[5][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2] +
                   f3[i]*hB[3] + f4[i]*hB[4] + f5[i]*hB[5]);
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

void encrypted_teleoperation_2021a_step(void)
{
  real_T rtb_TSamp;
  real_T rtb_TSamp_c;
  real_T rtb_TSamp_k;
  real_T rtb_TSamp_h;
  if (rtmIsMajorTimeStep(encrypted_teleoperation_2021_M)) {
    if (!(encrypted_teleoperation_2021_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&encrypted_teleoperation_2021_M->solverInfo,
                            ((encrypted_teleoperation_2021_M->Timing.clockTickH0
        + 1) * encrypted_teleoperation_2021_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&encrypted_teleoperation_2021_M->solverInfo,
                            ((encrypted_teleoperation_2021_M->Timing.clockTick0
        + 1) * encrypted_teleoperation_2021_M->Timing.stepSize0 +
        encrypted_teleoperation_2021_M->Timing.clockTickH0 *
        encrypted_teleoperation_2021_M->Timing.stepSize0 * 4294967296.0));
    }
  }

  if (rtmIsMinorTimeStep(encrypted_teleoperation_2021_M)) {
    encrypted_teleoperation_2021_M->Timing.t[0] = rtsiGetT
      (&encrypted_teleoperation_2021_M->solverInfo);
  }

  {
    real_T rtb_Derivative1;
    real_T rtb_Gain4;
    real_T rtb_Product2;
    real_T *lastU;
    encrypted_teleoperation_2021a_B.xm =
      encrypted_teleoperation_2021a_P.masterdynamics_C[0] *
      encrypted_teleoperation_2021a_X.masterdynamics_CSTATE[0];
    encrypted_teleoperation_2021a_B.xm +=
      encrypted_teleoperation_2021a_P.masterdynamics_C[1] *
      encrypted_teleoperation_2021a_X.masterdynamics_CSTATE[1];
    encrypted_teleoperation_2021a_Y.masterdisp =
      encrypted_teleoperation_2021a_B.xm;
    rtb_Derivative1 = encrypted_teleoperation_2021_M->Timing.t[0];
    if ((encrypted_teleoperation_2021_DW.TimeStampA >= rtb_Derivative1) &&
        (encrypted_teleoperation_2021_DW.TimeStampB >= rtb_Derivative1)) {
      rtb_Product2 = 0.0;
    } else {
      rtb_Gain4 = encrypted_teleoperation_2021_DW.TimeStampA;
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeA;
      if (encrypted_teleoperation_2021_DW.TimeStampA <
          encrypted_teleoperation_2021_DW.TimeStampB) {
        if (encrypted_teleoperation_2021_DW.TimeStampB < rtb_Derivative1) {
          rtb_Gain4 = encrypted_teleoperation_2021_DW.TimeStampB;
          lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeB;
        }
      } else if (encrypted_teleoperation_2021_DW.TimeStampA >= rtb_Derivative1)
      {
        rtb_Gain4 = encrypted_teleoperation_2021_DW.TimeStampB;
        lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeB;
      }

      rtb_Product2 = (encrypted_teleoperation_2021a_B.xm - *lastU) /
        (rtb_Derivative1 - rtb_Gain4);
    }

    if ((rtmIsMajorTimeStep(encrypted_teleoperation_2021_M) &&
         encrypted_teleoperation_2021_M->Timing.TaskCounters.TID[1] == 0) &&
        (rtmIsMajorTimeStep(encrypted_teleoperation_2021_M) &&
         encrypted_teleoperation_2021_M->Timing.TaskCounters.TID[2] == 0)) {
      encrypted_teleoperation_2021_DW.RateTransition_Buffer =
        encrypted_teleoperation_2021a_B.xm;
    }

    if (rtmIsMajorTimeStep(encrypted_teleoperation_2021_M) &&
        encrypted_teleoperation_2021_M->Timing.TaskCounters.TID[2] == 0) {
      encrypted_teleoperation_2021a_B.xm_discrete =
        encrypted_teleoperation_2021_DW.RateTransition_Buffer;
    }

    encrypted_teleoperation_2021a_B.xs =
      encrypted_teleoperation_2021a_P.slavedynamics_C[0] *
      encrypted_teleoperation_2021a_X.slavedynamics_CSTATE[0];
    encrypted_teleoperation_2021a_B.xs +=
      encrypted_teleoperation_2021a_P.slavedynamics_C[1] *
      encrypted_teleoperation_2021a_X.slavedynamics_CSTATE[1];
    if ((rtmIsMajorTimeStep(encrypted_teleoperation_2021_M) &&
         encrypted_teleoperation_2021_M->Timing.TaskCounters.TID[1] == 0) &&
        (rtmIsMajorTimeStep(encrypted_teleoperation_2021_M) &&
         encrypted_teleoperation_2021_M->Timing.TaskCounters.TID[2] == 0)) {
      encrypted_teleoperation_2021_DW.RateTransition1_Buffer =
        encrypted_teleoperation_2021a_B.xs;
    }

    if (rtmIsMajorTimeStep(encrypted_teleoperation_2021_M) &&
        encrypted_teleoperation_2021_M->Timing.TaskCounters.TID[2] == 0) {
      encrypted_teleoperation_2021a_B.xs_discrete =
        encrypted_teleoperation_2021_DW.RateTransition1_Buffer;
      rtb_TSamp = encrypted_teleoperation_2021a_B.xm_discrete *
        encrypted_teleoperation_2021a_P.TSamp_WtEt;
      encrypted_teleoperation_2021a_B.Diff = rtb_TSamp -
        encrypted_teleoperation_2021_DW.UD_DSTATE;
      rtb_TSamp_c = encrypted_teleoperation_2021a_B.Diff *
        encrypted_teleoperation_2021a_P.TSamp_WtEt_n;
      encrypted_teleoperation_2021a_B.Diff_p = rtb_TSamp_c -
        encrypted_teleoperation_2021_DW.UD_DSTATE_e;
      rtb_TSamp_k = encrypted_teleoperation_2021a_B.xs_discrete *
        encrypted_teleoperation_2021a_P.TSamp_WtEt_i;
      encrypted_teleoperation_2021a_B.Diff_e = rtb_TSamp_k -
        encrypted_teleoperation_2021_DW.UD_DSTATE_d;
      rtb_TSamp_h = encrypted_teleoperation_2021a_B.Diff_e *
        encrypted_teleoperation_2021a_P.TSamp_WtEt_i4;
      encrypted_teleoperation_2021a_B.Diff_g = rtb_TSamp_h -
        encrypted_teleoperation_2021_DW.UD_DSTATE_k;
      Linux_NoInput_Outputs_wrapper_cgen
        (&encrypted_teleoperation_2021a_B.xm_discrete,
         &encrypted_teleoperation_2021a_B.Diff,
         &encrypted_teleoperation_2021a_B.Diff_p,
         &encrypted_teleoperation_2021a_B.xs_discrete,
         &encrypted_teleoperation_2021a_B.Diff_e,
         &encrypted_teleoperation_2021a_B.Diff_g,
         &encrypted_teleoperation_2021a_P.mms,
         &encrypted_teleoperation_2021a_P.kms,
         &encrypted_teleoperation_2021a_P.bms,
         &encrypted_teleoperation_2021a_P.um,
         &encrypted_teleoperation_2021a_P.us,
         &encrypted_teleoperation_2021a_P.mm,
         &encrypted_teleoperation_2021a_P.ms,
         &encrypted_teleoperation_2021a_P.bit_length_Value,
         &encrypted_teleoperation_2021a_P.rho_Value,
         &encrypted_teleoperation_2021a_P.rho_Value_o,
         &encrypted_teleoperation_2021a_P.delta_Value,
         &encrypted_teleoperation_2021a_B.SFunctionBuilder_o1,
         &encrypted_teleoperation_2021a_B.SFunctionBuilder_o2,
         &encrypted_teleoperation_2021_DW.SFunctionBuilder_PWORK,
         &encrypted_teleoperation_2021a_P.SFunctionBuilder_P1, 1);
    }

    if (encrypted_teleoperation_2021_M->Timing.t[0] <
        encrypted_teleoperation_2021a_P.Step_Time) {
      rtb_Gain4 = encrypted_teleoperation_2021a_P.Step_Y0;
    } else {
      rtb_Gain4 = encrypted_teleoperation_2021a_P.fm;
    }

    if (!rtIsNaN(rtb_Product2)) {
      if (rtb_Product2 < 0.0) {
        rtb_Product2 = -1.0;
      } else {
        rtb_Product2 = (rtb_Product2 > 0.0);
      }
    }

    encrypted_teleoperation_2021a_B.Sum = (rtb_Gain4 +
      encrypted_teleoperation_2021a_B.SFunctionBuilder_o1) -
      encrypted_teleoperation_2021a_P.um * rtb_Product2;
    if ((encrypted_teleoperation_2021_DW.TimeStampA_k >= rtb_Derivative1) &&
        (encrypted_teleoperation_2021_DW.TimeStampB_j >= rtb_Derivative1)) {
      rtb_Product2 = 0.0;
    } else {
      rtb_Gain4 = encrypted_teleoperation_2021_DW.TimeStampA_k;
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeA_p;
      if (encrypted_teleoperation_2021_DW.TimeStampA_k <
          encrypted_teleoperation_2021_DW.TimeStampB_j) {
        if (encrypted_teleoperation_2021_DW.TimeStampB_j < rtb_Derivative1) {
          rtb_Gain4 = encrypted_teleoperation_2021_DW.TimeStampB_j;
          lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeB_m;
        }
      } else if (encrypted_teleoperation_2021_DW.TimeStampA_k >= rtb_Derivative1)
      {
        rtb_Gain4 = encrypted_teleoperation_2021_DW.TimeStampB_j;
        lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeB_m;
      }

      rtb_Product2 = (encrypted_teleoperation_2021a_B.xs - *lastU) /
        (rtb_Derivative1 - rtb_Gain4);
    }

    rtb_Gain4 = encrypted_teleoperation_2021a_P.benv * rtb_Product2;
    rtb_Product2 = encrypted_teleoperation_2021a_B.xs -
      encrypted_teleoperation_2021a_P.xbar;
    rtb_Product2 = (encrypted_teleoperation_2021a_P.kenv * rtb_Product2 +
                    rtb_Gain4) * (real_T)(rtb_Product2 >
      encrypted_teleoperation_2021a_P.CompareToConstant1_const);
    if ((encrypted_teleoperation_2021_DW.TimeStampA_a >= rtb_Derivative1) &&
        (encrypted_teleoperation_2021_DW.TimeStampB_f >= rtb_Derivative1)) {
      rtb_Derivative1 = 0.0;
    } else {
      rtb_Gain4 = encrypted_teleoperation_2021_DW.TimeStampA_a;
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeA_e;
      if (encrypted_teleoperation_2021_DW.TimeStampA_a <
          encrypted_teleoperation_2021_DW.TimeStampB_f) {
        if (encrypted_teleoperation_2021_DW.TimeStampB_f < rtb_Derivative1) {
          rtb_Gain4 = encrypted_teleoperation_2021_DW.TimeStampB_f;
          lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeB_d;
        }
      } else if (encrypted_teleoperation_2021_DW.TimeStampA_a >= rtb_Derivative1)
      {
        rtb_Gain4 = encrypted_teleoperation_2021_DW.TimeStampB_f;
        lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeB_d;
      }

      rtb_Derivative1 = (encrypted_teleoperation_2021a_B.xs - *lastU) /
        (rtb_Derivative1 - rtb_Gain4);
    }

    if (!rtIsNaN(rtb_Derivative1)) {
      if (rtb_Derivative1 < 0.0) {
        rtb_Derivative1 = -1.0;
      } else {
        rtb_Derivative1 = (rtb_Derivative1 > 0.0);
      }
    }

    encrypted_teleoperation_2021a_B.Sum1 =
      (encrypted_teleoperation_2021a_B.SFunctionBuilder_o2 - rtb_Product2) -
      encrypted_teleoperation_2021a_P.us * rtb_Derivative1;
    encrypted_teleoperation_2021a_Y.slavedisp =
      encrypted_teleoperation_2021a_B.xs;
  }

  if (rtmIsMajorTimeStep(encrypted_teleoperation_2021_M)) {
    fmu_LogOutput();
  }

  if (rtmIsMajorTimeStep(encrypted_teleoperation_2021_M)) {
    real_T *lastU;
    if (encrypted_teleoperation_2021_DW.TimeStampA == (rtInf)) {
      encrypted_teleoperation_2021_DW.TimeStampA =
        encrypted_teleoperation_2021_M->Timing.t[0];
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeA;
    } else if (encrypted_teleoperation_2021_DW.TimeStampB == (rtInf)) {
      encrypted_teleoperation_2021_DW.TimeStampB =
        encrypted_teleoperation_2021_M->Timing.t[0];
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeB;
    } else if (encrypted_teleoperation_2021_DW.TimeStampA <
               encrypted_teleoperation_2021_DW.TimeStampB) {
      encrypted_teleoperation_2021_DW.TimeStampA =
        encrypted_teleoperation_2021_M->Timing.t[0];
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeA;
    } else {
      encrypted_teleoperation_2021_DW.TimeStampB =
        encrypted_teleoperation_2021_M->Timing.t[0];
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeB;
    }

    *lastU = encrypted_teleoperation_2021a_B.xm;
    if (rtmIsMajorTimeStep(encrypted_teleoperation_2021_M) &&
        encrypted_teleoperation_2021_M->Timing.TaskCounters.TID[2] == 0) {
      encrypted_teleoperation_2021_DW.UD_DSTATE = rtb_TSamp;
      encrypted_teleoperation_2021_DW.UD_DSTATE_e = rtb_TSamp_c;
      encrypted_teleoperation_2021_DW.UD_DSTATE_d = rtb_TSamp_k;
      encrypted_teleoperation_2021_DW.UD_DSTATE_k = rtb_TSamp_h;
    }

    if (encrypted_teleoperation_2021_DW.TimeStampA_k == (rtInf)) {
      encrypted_teleoperation_2021_DW.TimeStampA_k =
        encrypted_teleoperation_2021_M->Timing.t[0];
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeA_p;
    } else if (encrypted_teleoperation_2021_DW.TimeStampB_j == (rtInf)) {
      encrypted_teleoperation_2021_DW.TimeStampB_j =
        encrypted_teleoperation_2021_M->Timing.t[0];
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeB_m;
    } else if (encrypted_teleoperation_2021_DW.TimeStampA_k <
               encrypted_teleoperation_2021_DW.TimeStampB_j) {
      encrypted_teleoperation_2021_DW.TimeStampA_k =
        encrypted_teleoperation_2021_M->Timing.t[0];
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeA_p;
    } else {
      encrypted_teleoperation_2021_DW.TimeStampB_j =
        encrypted_teleoperation_2021_M->Timing.t[0];
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeB_m;
    }

    *lastU = encrypted_teleoperation_2021a_B.xs;
    if (encrypted_teleoperation_2021_DW.TimeStampA_a == (rtInf)) {
      encrypted_teleoperation_2021_DW.TimeStampA_a =
        encrypted_teleoperation_2021_M->Timing.t[0];
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeA_e;
    } else if (encrypted_teleoperation_2021_DW.TimeStampB_f == (rtInf)) {
      encrypted_teleoperation_2021_DW.TimeStampB_f =
        encrypted_teleoperation_2021_M->Timing.t[0];
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeB_d;
    } else if (encrypted_teleoperation_2021_DW.TimeStampA_a <
               encrypted_teleoperation_2021_DW.TimeStampB_f) {
      encrypted_teleoperation_2021_DW.TimeStampA_a =
        encrypted_teleoperation_2021_M->Timing.t[0];
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeA_e;
    } else {
      encrypted_teleoperation_2021_DW.TimeStampB_f =
        encrypted_teleoperation_2021_M->Timing.t[0];
      lastU = &encrypted_teleoperation_2021_DW.LastUAtTimeB_d;
    }

    *lastU = encrypted_teleoperation_2021a_B.xs;
  }

  if (rtmIsMajorTimeStep(encrypted_teleoperation_2021_M)) {
    rt_ertODEUpdateContinuousStates(&encrypted_teleoperation_2021_M->solverInfo);
    if (!(++encrypted_teleoperation_2021_M->Timing.clockTick0)) {
      ++encrypted_teleoperation_2021_M->Timing.clockTickH0;
    }

    encrypted_teleoperation_2021_M->Timing.t[0] = rtsiGetSolverStopTime
      (&encrypted_teleoperation_2021_M->solverInfo);

    {
      encrypted_teleoperation_2021_M->Timing.clockTick1++;
      if (!encrypted_teleoperation_2021_M->Timing.clockTick1) {
        encrypted_teleoperation_2021_M->Timing.clockTickH1++;
      }
    }

    rate_scheduler();
  }
}

void encrypted_teleoperation_2021a_derivatives(void)
{
  XDot_encrypted_teleoperation__T *_rtXdot;
  _rtXdot = ((XDot_encrypted_teleoperation__T *)
             encrypted_teleoperation_2021_M->derivs);
  _rtXdot->masterdynamics_CSTATE[0] =
    encrypted_teleoperation_2021a_P.masterdynamics_A[0] *
    encrypted_teleoperation_2021a_X.masterdynamics_CSTATE[0];
  _rtXdot->slavedynamics_CSTATE[0] =
    encrypted_teleoperation_2021a_P.slavedynamics_A[0] *
    encrypted_teleoperation_2021a_X.slavedynamics_CSTATE[0];
  _rtXdot->masterdynamics_CSTATE[0] +=
    encrypted_teleoperation_2021a_P.masterdynamics_A[1] *
    encrypted_teleoperation_2021a_X.masterdynamics_CSTATE[1];
  _rtXdot->slavedynamics_CSTATE[0] +=
    encrypted_teleoperation_2021a_P.slavedynamics_A[1] *
    encrypted_teleoperation_2021a_X.slavedynamics_CSTATE[1];
  _rtXdot->masterdynamics_CSTATE[1] =
    encrypted_teleoperation_2021a_X.masterdynamics_CSTATE[0];
  _rtXdot->masterdynamics_CSTATE[0] += encrypted_teleoperation_2021a_B.Sum;
  _rtXdot->slavedynamics_CSTATE[1] =
    encrypted_teleoperation_2021a_X.slavedynamics_CSTATE[0];
  _rtXdot->slavedynamics_CSTATE[0] += encrypted_teleoperation_2021a_B.Sum1;
}

void encrypted_teleoperation_2021a_initialize(void)
{
  rt_InitInfAndNaN(sizeof(real_T));
  (void) memset((void *)encrypted_teleoperation_2021_M, 0,
                sizeof(RT_MODEL_encrypted_teleoperat_T));

  {
    rtsiSetSimTimeStepPtr(&encrypted_teleoperation_2021_M->solverInfo,
                          &encrypted_teleoperation_2021_M->Timing.simTimeStep);
    rtsiSetTPtr(&encrypted_teleoperation_2021_M->solverInfo, &rtmGetTPtr
                (encrypted_teleoperation_2021_M));
    rtsiSetStepSizePtr(&encrypted_teleoperation_2021_M->solverInfo,
                       &encrypted_teleoperation_2021_M->Timing.stepSize0);
    rtsiSetdXPtr(&encrypted_teleoperation_2021_M->solverInfo,
                 &encrypted_teleoperation_2021_M->derivs);
    rtsiSetContStatesPtr(&encrypted_teleoperation_2021_M->solverInfo, (real_T **)
                         &encrypted_teleoperation_2021_M->contStates);
    rtsiSetNumContStatesPtr(&encrypted_teleoperation_2021_M->solverInfo,
      &encrypted_teleoperation_2021_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&encrypted_teleoperation_2021_M->solverInfo,
      &encrypted_teleoperation_2021_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr
      (&encrypted_teleoperation_2021_M->solverInfo,
       &encrypted_teleoperation_2021_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr
      (&encrypted_teleoperation_2021_M->solverInfo,
       &encrypted_teleoperation_2021_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&encrypted_teleoperation_2021_M->solverInfo,
                          (&rtmGetErrorStatus(encrypted_teleoperation_2021_M)));
    rtsiSetRTModelPtr(&encrypted_teleoperation_2021_M->solverInfo,
                      encrypted_teleoperation_2021_M);
  }

  rtsiSetSimTimeStep(&encrypted_teleoperation_2021_M->solverInfo,
                     MAJOR_TIME_STEP);
  encrypted_teleoperation_2021_M->intgData.y =
    encrypted_teleoperation_2021_M->odeY;
  encrypted_teleoperation_2021_M->intgData.f[0] =
    encrypted_teleoperation_2021_M->odeF[0];
  encrypted_teleoperation_2021_M->intgData.f[1] =
    encrypted_teleoperation_2021_M->odeF[1];
  encrypted_teleoperation_2021_M->intgData.f[2] =
    encrypted_teleoperation_2021_M->odeF[2];
  encrypted_teleoperation_2021_M->intgData.f[3] =
    encrypted_teleoperation_2021_M->odeF[3];
  encrypted_teleoperation_2021_M->intgData.f[4] =
    encrypted_teleoperation_2021_M->odeF[4];
  encrypted_teleoperation_2021_M->intgData.f[5] =
    encrypted_teleoperation_2021_M->odeF[5];
  encrypted_teleoperation_2021_M->contStates = ((X_encrypted_teleoperation_202_T
    *) &encrypted_teleoperation_2021a_X);
  rtsiSetSolverData(&encrypted_teleoperation_2021_M->solverInfo, (void *)
                    &encrypted_teleoperation_2021_M->intgData);
  rtsiSetIsMinorTimeStepWithModeChange
    (&encrypted_teleoperation_2021_M->solverInfo, false);
  rtsiSetSolverName(&encrypted_teleoperation_2021_M->solverInfo,"ode5");
  rtmSetTPtr(encrypted_teleoperation_2021_M,
             &encrypted_teleoperation_2021_M->Timing.tArray[0]);
  encrypted_teleoperation_2021_M->Timing.stepSize0 = 0.001;
  (void) memset(((void *) &encrypted_teleoperation_2021a_B), 0,
                sizeof(B_encrypted_teleoperation_202_T));

  {
    (void) memset((void *)&encrypted_teleoperation_2021a_X, 0,
                  sizeof(X_encrypted_teleoperation_202_T));
  }

  (void) memset((void *)&encrypted_teleoperation_2021_DW, 0,
                sizeof(DW_encrypted_teleoperation_20_T));
  (void)memset(&encrypted_teleoperation_2021a_Y, 0, sizeof
               (ExtY_encrypted_teleoperation__T));
  encrypted_teleoperation_2021_DW.TimeStampA = (rtInf);
  encrypted_teleoperation_2021_DW.TimeStampB = (rtInf);
  encrypted_teleoperation_2021a_X.masterdynamics_CSTATE[0] = 0.0;
  encrypted_teleoperation_2021a_X.slavedynamics_CSTATE[0] = 0.0;
  encrypted_teleoperation_2021a_X.masterdynamics_CSTATE[1] = 0.0;
  encrypted_teleoperation_2021a_X.slavedynamics_CSTATE[1] = 0.0;
  encrypted_teleoperation_2021_DW.UD_DSTATE =
    encrypted_teleoperation_2021a_P.DiscreteDerivative2_ICPrevScale;
  encrypted_teleoperation_2021_DW.UD_DSTATE_e =
    encrypted_teleoperation_2021a_P.DiscreteDerivative3_ICPrevScale;
  encrypted_teleoperation_2021_DW.UD_DSTATE_d =
    encrypted_teleoperation_2021a_P.DiscreteDerivative4_ICPrevScale;
  encrypted_teleoperation_2021_DW.UD_DSTATE_k =
    encrypted_teleoperation_2021a_P.DiscreteDerivative5_ICPrevScale;
  encrypted_teleoperation_2021_DW.TimeStampA_k = (rtInf);
  encrypted_teleoperation_2021_DW.TimeStampB_j = (rtInf);
  encrypted_teleoperation_2021_DW.TimeStampA_a = (rtInf);
  encrypted_teleoperation_2021_DW.TimeStampB_f = (rtInf);
}

void encrypted_teleoperation_2021a_terminate(void)
{
}
