#ifndef _LINUX_NOINPUT_CGEN_WRAPPER_H_
#define _LINUX_NOINPUT_CGEN_WRAPPER_H_
#ifdef MATLAB_MEX_FILE
#include "tmwtypes.h"
#else
#include "rtwtypes.h"
#endif

#ifdef __cplusplus
#define SFB_EXTERN_C                   extern "C"
#else
#define SFB_EXTERN_C                   extern
#endif

SFB_EXTERN_C void Linux_NoInput_Outputs_wrapper_cgen(const real_T *xm,
  const real_T *dxm,
  const real_T *ddxm,
  const real_T *xs,
  const real_T *dxs,
  const real_T *ddxs,
  const real_T *mms,
  const real_T *kms,
  const real_T *bms,
  const real_T *um,
  const real_T *us,
  const real_T *mm,
  const real_T *ms,
  const real_T *bit_length,
  const real_T *rho,
  const real_T *rho_,
  const real_T *delta,
  real_T *tau_m,
  real_T *tau_s,
  void **pW,
  const real_T *p0, const int_T p_width0);

#undef SFB_EXTERN_C
#endif
