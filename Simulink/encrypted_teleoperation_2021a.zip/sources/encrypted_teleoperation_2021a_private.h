#ifndef RTW_HEADER_encrypted_teleoperation_2021a_private_h_
#define RTW_HEADER_encrypted_teleoperation_2021a_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"

#ifndef rtmIsMajorTimeStep
#define rtmIsMajorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
#define rtmIsMinorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmSetTPtr
#define rtmSetTPtr(rtm, val)           ((rtm)->Timing.t = (val))
#endif

#ifdef __cplusplus
#define SFB_EXTERN_C                   extern "C"
#else
#define SFB_EXTERN_C                   extern
#endif

SFB_EXTERN_C void Linux_NoInput_Start_wrapper(void **pW,
  const real_T *p0, const int_T p_width0);
SFB_EXTERN_C void Linux_NoInput_Outputs_wrapper(const real_T *xm,
  const real_T *dxm,
  const real_T *ddxm,
  const real_T *xs,
  const real_T *dxs,
  const real_T *ddxs,
  const real_T *mms,
  const real_T *kms,
  const real_T *bms,
  const real_T *um,
  const real_T *us,
  const real_T *mm,
  const real_T *ms,
  const real_T *bit_length,
  const real_T *rho,
  const real_T *rho_,
  const real_T *delta,
  real_T *tau_m,
  real_T *tau_s,
  void **pW,
  const real_T *p0, const int_T p_width0);
SFB_EXTERN_C void Linux_NoInput_Terminate_wrapper(void **pW,
  const real_T *p0, const int_T p_width0);

#undef SFB_EXTERN_C

extern void encrypted_teleoperation_2021a_derivatives(void);

#endif
