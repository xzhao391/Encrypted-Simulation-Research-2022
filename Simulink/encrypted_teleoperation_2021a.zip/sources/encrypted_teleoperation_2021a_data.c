#include "encrypted_teleoperation_2021a_macros.h"
#include "encrypted_teleoperation_2021a.h"

P_encrypted_teleoperation_202_T encrypted_teleoperation_2021a_P = {

  13.5,

  23.5,

  1.0,

  50.0,

  150.0,

  1.0,

  0.5,

  1.0,

  0.1,

  0.1,

  0.1,

  0.0,

  0.0,

  0.0,

  0.0,

  0.0,


  { -0.1, -0.0 },


  { 0.0, 1.0 },

  1.0,

  0.0,


  { -0.1, -0.0 },


  { 0.0, 1.0 },

  50.0,

  50.0,

  50.0,

  50.0,

  128.0,

  1.0,

  32.0,

  0.01,

  1.0
};
