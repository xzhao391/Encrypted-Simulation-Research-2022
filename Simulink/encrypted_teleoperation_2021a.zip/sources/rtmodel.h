#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "encrypted_teleoperation_2021a.h"
#define GRTINTERFACE                   0
#endif
